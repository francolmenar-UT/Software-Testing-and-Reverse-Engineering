package rers;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.runtime.EvoAssertions.*;

public class Problem11_ESTest {

    @Test(timeout = 4000)
    public void test00()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("C");
        problem11_0.calculateOutput("J");
        Assert.assertEquals(10, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test01()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1840022387 = "e";
        problem11_0.calculateOutput("D");
        Assert.assertEquals(9, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test02()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1840022387 = "e";
        problem11_0.a930233571 = 10;
        problem11_0.calculateOutput("D");
        Assert.assertEquals(9, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test03()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1227434655 = "i";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test04()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a130053513 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test05()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1857660363 = "g";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test06()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(11, problem11_0.a605263457);

        problem11_0.a605263457 = 10;
        problem11_0.calculateOutput("h");
        Assert.assertEquals(6, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test07()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a261374011 = "D";
        problem11_0.a605263457 = 10;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test08()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2135110469 = 1524;
        problem11_0.a605263457 = 10;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test09()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a892451458 = 9;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test10()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1115144307 = "Error ";
        problem11_0.a892451458 = 9;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test11()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a548397256 = "g";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test12()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 13;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test13()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1224468176 = "g";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test14()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1224468176 = "g";
        problem11_0.a1228149849 = 1009;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test15()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1644705049 = "i";
        problem11_0.a1488435031 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test16()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a868982691 = 15;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test17()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1074202851 = "e";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test18()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1228149849 = 5;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test19()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a930233571 = 11;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test20()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 8;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test21()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1790587420 = 7;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test22()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1718050978 = "i";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test23()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a344522688 = "Error ";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test24()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("D");
        problem11_0.calculateOutput("F");
        problem11_0.calculateOutput("D");
        Assert.assertEquals(8, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test25()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a589537721 = 4;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test26()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 4;
        problem11_0.a589537721 = 4;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("B");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test27()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1790587420 = 13;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test28()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1857660363 = "h";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test29()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1224468176 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test30()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1224468176 = "f";
        problem11_0.a1228149849 = 1530;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("P#LU%%nOfio($#1");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test31()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a898912231 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test32()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a930233571 = 8;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test33()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("C");
        problem11_0.calculateOutput("B");
        problem11_0.calculateOutput("C");
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("C");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test34()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a930233571 = 6;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test35()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(6, problem11_0.a2135110469);

        problem11_0.a1115144307 = "g";
        problem11_0.a2135110469 = 9;
        problem11_0.calculateOutput("3CKjW)`7i");
        Assert.assertEquals(8, problem11_0.a1342468697);
    }

    @Test(timeout = 4000)
    public void test36()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1781711932 = 6;
        problem11_0.calculateOutput("C");
        problem11_0.calculateOutput("B");
        Assert.assertEquals(4, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test37()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 11;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test38()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(2, problem11_0.a1228149849);
        assertTrue(problem11_0.cf);

        problem11_0.a2135110469 = 7;
        problem11_0.calculateOutput("e");
        Assert.assertEquals(9, problem11_0.a1781711932);
    }

    @Test(timeout = 4000)
    public void test39()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1342468697 = 7;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test40()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1228149849 = 9;
        problem11_0.a1857660363 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test41()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a554980914 = 12;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test42()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a975106081 = "i";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test43()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a892451458 = 11;
        problem11_0.calculateOutput("D");
        Assert.assertEquals(9, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test44()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("C");
        problem11_0.calculateOutput("B");
        problem11_0.calculateOutput("D");
        problem11_0.a2135110469 = (-701);
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("D");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test45()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2062504165 = 8;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test46()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1293654158 = 13;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test47()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        assertTrue(problem11_0.cf);

        problem11_0.a261374011 = "g";
        problem11_0.a1293654158 = 13;
        problem11_0.calculateOutput("I");
        Assert.assertEquals(9, problem11_0.a1781711932);
    }

    @Test(timeout = 4000)
    public void test48()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(15, problem11_0.a2128198108);
        Assert.assertEquals(6, problem11_0.a2135110469);

        problem11_0.a261374011 = "g";
        problem11_0.a2135110469 = 5;
        problem11_0.a1293654158 = 13;
        problem11_0.calculateOutput("I");
        Assert.assertEquals(8, problem11_0.a1342468697);
    }

    @Test(timeout = 4000)
    public void test49()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 12;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test50()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a898912231 = "g";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test51()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1074202851 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test52()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1228149849 = 9;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test53()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(6, problem11_0.a2135110469);

        problem11_0.a1228149849 = 9;
        problem11_0.a2135110469 = 7;
        problem11_0.calculateOutput("g");
        Assert.assertEquals(10, problem11_0.a868982691);
    }

    @Test(timeout = 4000)
    public void test54()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("D");
        problem11_0.calculateOutput("B");
        Assert.assertEquals(13, problem11_0.a2128198108);
    }

    @Test(timeout = 4000)
    public void test55()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a261374011 = "g";
        problem11_0.a2135110469 = 9;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test56()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1342468697 = 5;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("e");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test57()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a605263457 = 13;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test58()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1840022387 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test59()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2062504165 = 6;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test60()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1553956613 = "i";
        problem11_0.a1644705049 = "i";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test61()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1115144307 = "";
        problem11_0.a892451458 = 13;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test62()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a286091846 = "h";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test63()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 1855;
        problem11_0.a589537721 = 8;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test64()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a605263457 = 14;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test65()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a554980914 = 16;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test66()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1644705049 = "f";
        problem11_0.a286091846 = "f";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test67()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a930233571 = 7;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test68()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1342468697 = 6;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test69()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2062504165 = 4;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("g");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test70()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1840022387 = "g";
        problem11_0.calculateOutput("D");
        Assert.assertEquals(9, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test71()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1840022387 = "g";
        problem11_0.a930233571 = 14;
        problem11_0.calculateOutput("D");
        Assert.assertEquals(9, problem11_0.a2135110469);
    }

    @Test(timeout = 4000)
    public void test72()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2128198108 = 10;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test73()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1228149849 = 8;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test74()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        Assert.assertEquals(6, problem11_0.a2135110469);

        problem11_0.a2135110469 = 3;
        problem11_0.calculateOutput("g");
        Assert.assertEquals(8, problem11_0.a1342468697);
    }

    @Test(timeout = 4000)
    public void test75()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1644705049 = "f";
        problem11_0.a286091846 = "h";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("h");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test76()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a1074202851 = "C";
        problem11_0.a1781711932 = 10;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("f");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test77()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("C");
        problem11_0.calculateOutput("B");
        problem11_0.calculateOutput("D");
        problem11_0.calculateOutput("D");
        Assert.assertEquals(8, problem11_0.a2062504165);
    }

    @Test(timeout = 4000)
    public void test78()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("D");
        problem11_0.calculateOutput("F");
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("F");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test79()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("C");
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("C");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test80()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        assertTrue(problem11_0.cf);

        problem11_0.a2135110469 = 8;
        problem11_0.calculateOutput("f");
        Assert.assertEquals(15, problem11_0.a2128198108);
    }

    @Test(timeout = 4000)
    public void test81()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.calculateOutput("D");
        problem11_0.a130053513 = "";
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("i");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

    @Test(timeout = 4000)
    public void test82()  throws Throwable  {
        Problem11 problem11_0 = new Problem11();
        problem11_0.a2135110469 = 4;
        // Undeclared exception!
        try {
            problem11_0.calculateOutput("D");
            fail("Expecting exception: IllegalArgumentException");

        } catch(IllegalArgumentException e) {
            //
            // Current state has no transition for this input!
            //
            verifyException("rers.Problem11", e);
        }
    }

}
