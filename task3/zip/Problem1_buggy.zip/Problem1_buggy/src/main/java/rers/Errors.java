package rers;

public class Errors {
	public static void __VERIFIER_error(int value){
		System.out.println("Error "+ value);
	}
}