package rers;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem1 {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"F","E","I","J","A","D","H","G","C","B"};

	public String a102639762 = "h";
	public boolean cf = true;
	public String a2039526293 = "h";
	public String a430079676 = "f";
	public int a1731117979 = 10;

private  void calculateOutputm1(String input) {
    if(((((input.equals("C")) && cf) && (a430079676.equals("e"))) && (a2039526293.equals("e")))) {
    	cf = false;
    	a430079676 = "f";
    	a1731117979 = 7; 
    	System.out.println("R");
    } if(((input.equals("D")) && ((cf && (a2039526293.equals("e"))) && (a430079676.equals("e"))))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "i"; 
    	System.out.println("Z");
    } if(((input.equals("J")) && ((a430079676.equals("e")) && ((a2039526293.equals("e")) && cf)))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "h";
    	System.out.println("X");
    } 
}
private  void calculateOutputm2(String input) {
    if((((cf && (a430079676.equals("e"))) && (a2039526293.equals("g"))) && (input.equals("A")))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "i"; 
    	System.out.println("T");
    } if(((a2039526293.equals("g")) && ((cf && (a430079676.equals("e"))) && (input.equals("D"))))) {
    	cf = false;
    	a2039526293 = "e"; 
    	System.out.println("X");
    } if(((((a430079676.equals("e")) && cf) && (input.equals("F"))) && (a2039526293.equals("g")))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "i"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm3(String input) {
    if((((cf && (input.equals("A"))) && (a430079676.equals("e"))) && (a2039526293.equals("h")))) {
    	cf = false;
    	a430079676 = "f";
    	a1731117979 = 5; 
    	System.out.println("W");
    } if((((input.equals("C")) && ((a2039526293.equals("h")) && cf)) && (a430079676.equals("e")))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "i"; 
    	System.out.println("T");
    } if((((a2039526293.equals("h")) && ((input.equals("H")) && cf)) && (a430079676.equals("e")))) {
    	cf = false;
    	a2039526293 = "e"; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm4(String input) {
    if(((a2039526293.equals("i")) && ((a430079676.equals("e")) && (cf && (input.equals("D")))))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "f"; 
    	System.out.println("V");
    } if(((input.equals("G")) && (((a430079676.equals("e")) && cf) && (a2039526293.equals("i"))))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "g"; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm5(String input) {
    if(((input.equals("A")) && ((a430079676.equals("f")) && ((a1731117979 == 5) && cf)))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "h"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm6(String input) {
    if(((((a430079676.equals("f")) && cf) && (input.equals("C"))) && (a1731117979 == 6))) {
    	cf = false;
    	 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm7(String input) {
    if((((input.equals("G")) && (cf && (a1731117979 == 7))) && (a430079676.equals("f")))) {
    	cf = false;
    	a1731117979 = 9; 
    	System.out.println("Z");
    } if(((a1731117979 == 7) && ((input.equals("H")) && ((a430079676.equals("f")) && cf)))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "e"; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm8(String input) {
    if((((input.equals("B")) && (cf && (a1731117979 == 9))) && (a430079676.equals("f")))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "g"; 
    	System.out.println("S");
    } if((((cf && (a430079676.equals("f"))) && (input.equals("G"))) && (a1731117979 == 9))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "g"; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm9(String input) {
    if((((cf && (a430079676.equals("f"))) && (a1731117979 == 10)) && (input.equals("H")))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "f"; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm10(String input) {
    if(((a1731117979 == 11) && ((a430079676.equals("f")) && (cf && (input.equals("H")))))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "i"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm11(String input) {
    if(((((input.equals("J")) && cf) && (a102639762.equals("e"))) && (a430079676.equals("g")))) {
    	cf = false;
    	a430079676 = "f";
    	a1731117979 = 6; 
    	System.out.println("Q");
    } 
}
private  void calculateOutputm12(String input) {
    if((((input.equals("B")) && (cf && (a430079676.equals("g")))) && (a102639762.equals("f")))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "i"; 
    	System.out.println("Z");
    } if(((a430079676.equals("g")) && ((cf && (input.equals("H"))) && (a102639762.equals("f"))))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "e"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm13(String input) {
    if(((((a102639762.equals("g")) && cf) && (input.equals("C"))) && (a430079676.equals("g")))) {
    	cf = false;
    	a102639762 = "f"; 
    	System.out.println("Z");
    } if(((a430079676.equals("g")) && ((a102639762.equals("g")) && (cf && (input.equals("D")))))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "i"; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm14(String input) {
    if(((a430079676.equals("g")) && ((input.equals("J")) && (cf && (a102639762.equals("h")))))) {
    	cf = false;
    	 
    	System.out.println("S");
    } 
}
private  void calculateOutputm15(String input) {
    if((((a430079676.equals("g")) && (cf && (input.equals("B")))) && (a102639762.equals("i")))) {
    	cf = false;
    	a430079676 = "h";
    	a102639762 = "h"; 
    	System.out.println("Y");
    } if((((cf && (input.equals("D"))) && (a102639762.equals("i"))) && (a430079676.equals("g")))) {
    	cf = false;
    	 
    	System.out.println("T");
    } if(((input.equals("H")) && (((a102639762.equals("i")) && cf) && (a430079676.equals("g"))))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "f"; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm16(String input) {
    if((((cf && (a102639762.equals("f"))) && (a430079676.equals("h"))) && (input.equals("G")))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "i"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm17(String input) {
    if(((((input.equals("A")) && cf) && (a430079676.equals("h"))) && (a102639762.equals("g")))) {
    	cf = false;
    	 
    	System.out.println("T");
    } if(((input.equals("H")) && ((a102639762.equals("g")) && (cf && (a430079676.equals("h")))))) {
    	cf = false;
    	a430079676 = "f";
    	a1731117979 = 7; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm18(String input) {
    if(((a102639762.equals("h")) && ((cf && (a430079676.equals("h"))) && (input.equals("A"))))) {
    	cf = false;
    	 
    	System.out.println("R");
    } if(((input.equals("D")) && ((a430079676.equals("h")) && ((a102639762.equals("h")) && cf)))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "e"; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm19(String input) {
    if(((input.equals("G")) && ((a102639762.equals("i")) && ((a430079676.equals("h")) && cf)))) {
    	cf = false;
    	a430079676 = "i";
    	a102639762 = "f"; 
    	System.out.println("Z");
    } if(((a102639762.equals("i")) && ((input.equals("H")) && (cf && (a430079676.equals("h")))))) {
    	cf = false;
    	a430079676 = "f";
    	a1731117979 = 11; 
    	System.out.println("P");
    } 
}
private  void calculateOutputm20(String input) {
    if(((a102639762.equals("f")) && ((cf && (a430079676.equals("i"))) && (input.equals("B"))))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "h"; 
    	System.out.println("U");
    } if((((cf && (a102639762.equals("f"))) && (input.equals("G"))) && (a430079676.equals("i")))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "g"; 
    	System.out.println("R");
    } 
}
private  void calculateOutputm21(String input) {
    if(((a102639762.equals("g")) && ((input.equals("B")) && (cf && (a430079676.equals("i")))))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "i"; 
    	System.out.println("R");
    } if(((a430079676.equals("i")) && (((input.equals("C")) && cf) && (a102639762.equals("g"))))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "e"; 
    	System.out.println("R");
    } if((((cf && (a102639762.equals("g"))) && (a430079676.equals("i"))) && (input.equals("D")))) {
    	cf = false;
    	a430079676 = "g"; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm22(String input) {
    if(((((a102639762.equals("h")) && cf) && (a430079676.equals("i"))) && (input.equals("D")))) {
    	cf = false;
    	a430079676 = "g";
    	a102639762 = "e"; 
    	System.out.println("S");
    } if(((a102639762.equals("h")) && (((a430079676.equals("i")) && cf) && (input.equals("H"))))) {
    	cf = false;
    	a430079676 = "g"; 
    	System.out.println("S");
    } if(((input.equals("J")) && ((a430079676.equals("i")) && (cf && (a102639762.equals("h")))))) {
    	cf = false;
    	a430079676 = "h"; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm23(String input) {
    if(((a430079676.equals("i")) && ((input.equals("D")) && ((a102639762.equals("i")) && cf)))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "g"; 
    	System.out.println("T");
    } if((((input.equals("G")) && ((a102639762.equals("i")) && cf)) && (a430079676.equals("i")))) {
    	cf = false;
    	a430079676 = "e";
    	a2039526293 = "e"; 
    	System.out.println("Z");
    } if(((a102639762.equals("i")) && (((a430079676.equals("i")) && cf) && (input.equals("J"))))) {
    	cf = false;
    	 
    	System.out.println("T");
    } 
}



public  void calculateOutput(String input) {
 	cf = true;
    if(((a430079676.equals("e")) && cf)) {
    	if((cf && (a2039526293.equals("e")))) {
    		calculateOutputm1(input);
    	} 
    	if((cf && (a2039526293.equals("g")))) {
    		calculateOutputm2(input);
    	} 
    	if(((a2039526293.equals("h")) && cf)) {
    		calculateOutputm3(input);
    	} 
    	//if(((a2039526293.equals("i")) && cf)) {
    	//	calculateOutputm4(input);
    	//}
    } 
    if((cf && (a430079676.equals("f")))) {
    	if(((a1731117979 == 5) && cf)) {
    		calculateOutputm5(input);
    	} 
    	if((cf && (a1731117979 == 6))) {
    		calculateOutputm6(input);
    	} 
    	if(((a1731117979 == 7) && cf)) {
    		calculateOutputm7(input);
    	} 
    	if(((a1731117979 == 9) && cf)) {
    		calculateOutputm8(input);
    	} 
    	if(((a1731117979 == 10) && cf)) {
    		calculateOutputm9(input);
    	} 
    	if(((a1731117979 == 11) && cf)) {
    		calculateOutputm10(input);
    	} 
    } 
    if(((a430079676.equals("g")) && cf)) {
    	if(((a102639762.equals("e")) && cf)) {
    		calculateOutputm11(input);
    	} 
    	if(((a102639762.equals("f")) && cf)) {
    		calculateOutputm12(input);
    	} 
    	if(((a102639762.equals("g")) && cf)) {
    		calculateOutputm13(input);
    	} 
    	if(((a102639762.equals("h")) && cf)) {
    		calculateOutputm14(input);
    	} 
    	if((cf && (a102639762.equals("i")))) {
    		calculateOutputm15(input);
    	} 
    } 
    if(((a430079676.equals("h")) && cf)) {
    	if((cf && (a102639762.equals("f")))) {
    		calculateOutputm16(input);
    	} 
    	if((cf && (a102639762.equals("g")))) {
    		calculateOutputm17(input);
    	} 
    	if(((a102639762.equals("h")) && cf)) {
    		calculateOutputm18(input);
    	} 
    	if((cf && (a102639762.equals("i")))) {
    		calculateOutputm19(input);
    	} 
    } 
    if(((a430079676.equals("i")) && cf)) {
    	if(((a102639762.equals("f")) && cf)) {
    		calculateOutputm20(input);
    	} 
    	if((cf && (a102639762.equals("g")))) {
    		calculateOutputm21(input);
    	} 
    	if(((a102639762.equals("h")) && cf)) {
    		calculateOutputm22(input);
    	} 
    	if((cf && (a102639762.equals("i")))) {
    		calculateOutputm23(input);
    	} 
    } 


    if(cf)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main(String[] args) throws Exception {
	// init system and input reader
	Problem1 eca = new Problem1();

	// main i/o-loop
	while(true) {
		//read input
		String input = stdin.readLine();

		 if((input.equals("F")) && (input.equals("E")) && (input.equals("I")) && (input.equals("J")) && (input.equals("A")) && (input.equals("D")) && (input.equals("H")) && (input.equals("G")) && (input.equals("C")) && (input.equals("B")))
			throw new IllegalArgumentException("Current state has no transition for this input!");
		try {
			//operate eca engine output = 
			eca.calculateOutput(input);
		} catch(IllegalArgumentException e) {
			System.err.println("Invalid input: " + e.getMessage());
		}
	}
}
}