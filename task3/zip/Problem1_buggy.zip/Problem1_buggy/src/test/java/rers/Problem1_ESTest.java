package rers;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.runtime.EvoAssertions.*;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.evosuite.runtime.util.SystemInUtil;
import org.junit.runner.RunWith;

public class Problem1_ESTest {

  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      assertTrue(problem1_0.cf);
      
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("F");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.calculateOutput("H");
      problem1_0.calculateOutput("H");
      problem1_0.calculateOutput("C");
      assertEquals(7, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("J");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("A");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("D");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      assertTrue(problem1_0.cf);
      
      problem1_0.a430079676 = "e";
      problem1_0.calculateOutput("C");
      problem1_0.calculateOutput("H");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "e";
      problem1_0.calculateOutput("A");
      assertEquals(5, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      assertTrue(problem1_0.cf);
      
      problem1_0.a430079676 = "e";
      problem1_0.calculateOutput("H");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      assertTrue(problem1_0.cf);
      
      problem1_0.a102639762 = "f";
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("D");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      assertTrue(problem1_0.cf);
      
      problem1_0.a102639762 = "f";
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("G");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 5;
      problem1_0.calculateOutput("A");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 6;
      problem1_0.calculateOutput("C");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 7;
      problem1_0.calculateOutput("H");
      assertEquals(7, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 7;
      problem1_0.calculateOutput("G");
      assertEquals(9, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 9;
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("B");
      assertEquals(9, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 9;
      problem1_0.calculateOutput("B");
      assertEquals(9, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test23()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 11;
      problem1_0.calculateOutput("H");
      assertEquals(11, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test26()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "i";
      problem1_0.calculateOutput("D");
      problem1_0.calculateOutput("J");
      assertEquals(6, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test27()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.calculateOutput("H");
      problem1_0.calculateOutput("B");
      problem1_0.calculateOutput("H");
      assertEquals(11, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test29()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "g";
      problem1_0.a102639762 = "g";
      problem1_0.calculateOutput("D");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test30()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "g";
      problem1_0.a102639762 = "g";
      problem1_0.calculateOutput("C");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test33()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "g";
      problem1_0.calculateOutput("J");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test34()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "e";
      problem1_0.calculateOutput("C");
      problem1_0.calculateOutput("B");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test35()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "e";
      problem1_0.calculateOutput("C");
      problem1_0.calculateOutput("D");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test37()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.a102639762 = "g";
      problem1_0.calculateOutput("H");
      assertEquals(7, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test38()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.a102639762 = "g";
      problem1_0.calculateOutput("A");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test39()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("A");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test41()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a102639762 = "i";
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("B");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test42()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a102639762 = "i";
      problem1_0.a430079676 = "h";
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("G");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test44()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 9;
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("D");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test45()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a1731117979 = 9;
      problem1_0.calculateOutput("G");
      problem1_0.calculateOutput("C");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test47()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a430079676 = "i";
      problem1_0.calculateOutput("H");
      assertFalse(problem1_0.cf);
  }

  @Test(timeout = 4000)
  public void test48()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a102639762 = "i";
      problem1_0.a430079676 = "i";
      problem1_0.calculateOutput("G");
      assertEquals(10, problem1_0.a1731117979);
  }

  @Test(timeout = 4000)
  public void test49()  throws Throwable  {
      Problem1 problem1_0 = new Problem1();
      problem1_0.a102639762 = "i";
      problem1_0.a430079676 = "i";
      problem1_0.calculateOutput("J");
      assertEquals(10, problem1_0.a1731117979);
  }
}
