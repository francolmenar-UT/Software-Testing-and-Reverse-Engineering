package rers;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.runtime.EvoAssertions.*;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.evosuite.runtime.util.SystemInUtil;
import org.junit.runner.RunWith;

public class m158_LTL_ESTest {

  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "e";
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "e";
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals(13, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test02()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re14");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai3_re14");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test03()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re14");
      m158_LTL0.calculateOutput("usr2_ai3_re14");
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a1143678624 = 3566;
      m158_LTL0.a744592626 = "f";
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai2_VoidReply");
      assertEquals(10, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test05()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a1614029224 = 8;
      m158_LTL0.a744592626 = "e";
      m158_LTL0.calculateOutput("e");
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re12");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      assertEquals(6, m158_LTL0.a1614029224);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test07()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re12");
      m158_LTL0.calculateOutput("usr2_ai3_re12");
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 13;
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals(10, m158_LTL0.a1614029224);
      
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      assertEquals(42, m158_LTL0.a2018512586);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test09()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 13;
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 11;
      m158_LTL0.calculateOutput("usr3_ai2_re2");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals(12, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test11()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 11;
      m158_LTL0.calculateOutput("usr3_ai2_re2");
      m158_LTL0.calculateOutput("usr3_ai2_re2");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test12()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a1614029224 = 12;
      m158_LTL0.a744592626 = "e";
      m158_LTL0.calculateOutput("e");
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 7;
      m158_LTL0.calculateOutput("usr2_ai2_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai2_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai2_VoidReply");
      assertEquals((-58), m158_LTL0.a2018512586);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test14()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "f";
      m158_LTL0.calculateOutput("f");
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "f";
      m158_LTL0.a1143678624 = 116;
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      assertEquals(17, m158_LTL0.a2018512586);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test16()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "g";
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      m158_LTL0.calculateOutput("g");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test17()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "f";
      m158_LTL0.a1143678624 = 1332;
      m158_LTL0.calculateOutput("f");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test18()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re11");
      m158_LTL0.calculateOutput("usr2_ai3_re11");
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re11");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      assertEquals(148, m158_LTL0.a2018512586);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test20()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "f";
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test21()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "g";
      m158_LTL0.calculateOutput("g");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test22()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 7;
      m158_LTL0.calculateOutput("h");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test23()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re9");
      m158_LTL0.calculateOutput("usr2_ai3_re9");
  }

  @Test(timeout = 4000)
  public void test24()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re10");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      assertEquals(9, m158_LTL0.a2046636204);
  }

  @Test(timeout = 4000)
  public void test25()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re13");
      assertEquals(14, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test26()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re7");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test27()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re19");
      m158_LTL0.calculateOutput("usr2_ai3_re19");
  }

  @Test(timeout = 4000)
  public void test28()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re8");
      assertEquals(9, m158_LTL0.a1614029224);
  }

  @Test(timeout = 4000)
  public void test29()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 9;
      m158_LTL0.calculateOutput("usr4_ai2_VoidReply");
      assertEquals(8, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test30()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 9;
      m158_LTL0.calculateOutput("h");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test31()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 10;
      m158_LTL0.calculateOutput("h");
  }

  @Test(timeout = 4000)
  public void test32()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 11;
      m158_LTL0.calculateOutput("usr3_ai2_re1");
      assertEquals(9, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = NullPointerException.class)
  public void test33()  throws Throwable  {
      SystemInUtil.addInputLine("usr3_ai2_re1");
      String[] stringArray0 = new String[0];
      m158_LTL.main(stringArray0);
  }

  @Test(timeout = 4000)
  public void test34()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      assertEquals(12, m158_LTL0.a2100499434);
      
      m158_LTL0.calculateOutput("ai1_ce1");
      assertEquals(11, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test35()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 13;
      m158_LTL0.calculateOutput("h");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test36()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 14;
      m158_LTL0.calculateOutput("h");
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test37()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "i";
      m158_LTL0.calculateOutput("i");
  }

  @Test(timeout = 4000)
  public void test38()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a744592626 = "i";
      m158_LTL0.calculateOutput("usr1_ai2_VoidReply");
      assertEquals(7, m158_LTL0.a2100499434);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test39()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re7");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      m158_LTL0.calculateOutput("usr2_ai3_re7");
  }

  @Test(timeout = 4000)
  public void test40()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re7");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals(7, m158_LTL0.a2046636204);
  }

  @Test(timeout = 4000)
  public void test41()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re14");
      m158_LTL0.calculateOutput("usr2_ai3_VoidReply");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals((-21281), m158_LTL0.a1143678624);
  }

  @Test(timeout = 4000)
  public void test42()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2100499434 = 8;
      m158_LTL0.calculateOutput("usr2_ai3_re19");
      m158_LTL0.calculateOutput("usr1_ai1_VoidReply");
      assertEquals(11, m158_LTL0.a2046636204);
  }

  @Test(timeout = 4000, expected = IllegalArgumentException.class)
  public void test43()  throws Throwable  {
      m158_LTL m158_LTL0 = new m158_LTL();
      m158_LTL0.a2018512586 = 511;
      m158_LTL0.a744592626 = "g";
      m158_LTL0.calculateOutput("g");
  }

  @Test(timeout = 4000, expected = NullPointerException.class)
  public void test44()  throws Throwable  {
      SystemInUtil.addInputLine("h");
      String[] stringArray0 = new String[39];
      m158_LTL.main(stringArray0);
  }
}
