package rers;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class m158_LTL {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"usr3_ai2_re1","usr3_ai2_re2","usr2_ai3_re7","usr2_ai3_re8","usr2_ai3_re9","usr4_ai2_VoidReply","usr1_ai1_VoidReply","usr2_ai3_VoidReply","usr1_ai2_VoidReply","usr2_ai2_VoidReply","usr2_ai3_re12","usr2_ai3_re19","ai1_ce1","usr2_ai3_re13","usr2_ai3_re10","usr2_ai3_re11","usr2_ai3_re14"};

	public int a2100499434 = 12;
	public int a2046636204 = 4;
	public int a2018512586 = 42;
	public int a1143678624 = 8;
	public boolean cf = true;
	public String a744592626 = "h";
	public int a1614029224 = 6;

private  void calculateOutputm1(String input) {
    if((cf && (input.equals("usr1_ai1_VoidReply")))) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = (a1614029224 - -7); 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm2(String input) {
    if((cf && (input.equals("usr2_ai3_VoidReply")))) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = (a1614029224 - -3); 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm3(String input) {
    if((cf && (input.equals("usr2_ai2_VoidReply")))) {
    	cf = false;
    	a744592626 = "g";
    	a2018512586 = (((1 + 22) / 5) + 9); 
    	System.out.println("usr2_ai2_ce12");
    } 
}
private  void calculateOutputm4(String input) {
    if((cf && (input.equals("usr2_ai3_VoidReply")))) {
    	cf = false;
    	a1614029224 = 6; 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm5(String input) {
    if((cf && (input.equals("usr1_ai2_VoidReply")))) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = (a1614029224 - 6); 
    	System.out.println("usr1_ai2_ce10");
    } 
}
private  void calculateOutputm6(String input) {
    if((cf && (input.equals("usr1_ai1_VoidReply")))) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = (a1614029224 - -1); 
    	System.out.println("ai1_re3");
    } 
}
private  void calculateOutputm7(String input) {
    if(((input.equals("usr2_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = a1614029224; 
    	System.out.println("ai1_re1");
    } 
}
private  void calculateOutputm8(String input) {
    if(((input.equals("usr1_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "g";
    	a2018512586 = (((((((a1143678624 * a1143678624) % 14999) % 100) - 63) - 3) - 14575) + 14577); 
    	System.out.println("usr2_ai2_ce12");
    } 
}
private  void calculateOutputm9(String input) {
    if((cf && (input.equals("usr1_ai2_VoidReply")))) {
    	cf = false;
    	a744592626 = "g";
    	a2018512586 = (((((((a1143678624 * a1143678624) % 14999) - -929) + -12895) * 2) % 100) - 63); 
    	System.out.println("usr2_ai2_ce13");
    } 
}
private  void calculateOutputm10(String input) {
    if((cf && (input.equals("usr1_ai2_VoidReply")))) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = 10; 
    	System.out.println("usr1_ai2_ce10");
    } 
}
private  void calculateOutputm11(String input) {
    if(((input.equals("usr2_ai3_VoidReply")) && cf)) {
    	cf = false;
    	a2018512586 = (((((a2018512586 * 1) * 1) - -18761) % 84) + 120); 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm12(String input) {
    if(((input.equals("usr2_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = 12; 
    	System.out.println("usr2_ai2_ce14");
    } 
}
private  void calculateOutputm13(String input) {
    if((cf && (input.equals("usr1_ai1_VoidReply")))) {
    	cf = false;
    	a744592626 = "f";
    	a1143678624 = ((((((a2018512586 * a2018512586) % 14999) / 5) % 107) + 93) + -8); 
    	System.out.println("usr1_ai2_ce10");
    } 
}
private  void calculateOutputm14(String input) {
    if(((input.equals("usr2_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "g";
    	a2018512586 = (((((26 * 10) / 9) * 9) / 10) - 83); 
    	System.out.println("usr2_ai2_ce13");
    } 
}
private  void calculateOutputm15(String input) {
    if(((input.equals("usr2_ai3_re9")) && cf)) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = (a2100499434 - -1); 
    	System.out.println("usr2_ai3_ce9");
    } if(((input.equals("usr2_ai3_re10")) && cf)) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = ((a2100499434 - a2100499434) - -9); 
    	System.out.println("usr2_ai3_ce10");
    } if((cf && (input.equals("usr2_ai3_re11")))) {
    	cf = false;
    	a744592626 = "g";
    	a2018512586 = (((((49 * -34) / 10) - -26221) * -1) / 10); 
    	System.out.println("usr2_ai3_ce11");
    } if(((input.equals("usr2_ai3_re12")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = ((a2100499434 / a2100499434) - -8); 
    	System.out.println("usr2_ai3_ce12");
    } if((cf && (input.equals("usr2_ai3_re13")))) {
    	cf = false;
    	a2100499434 = 14; 
    	System.out.println("usr2_ai3_ce13");
    } if(((input.equals("usr2_ai3_re14")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = ((a2100499434 / a2100499434) - -6); 
    	System.out.println("usr2_ai3_ce14");
    } if((cf && (input.equals("usr2_ai3_re19")))) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = (a2100499434 - -3); 
    	System.out.println("usr1_ai1_ce20");
    } if(((input.equals("usr2_ai3_re7")) && cf)) {
    	cf = false;
    	a2100499434 = 14; 
    	System.out.println("usr2_ai3_ce7");
    } if(((input.equals("usr2_ai3_re8")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = (a2100499434 + 1); 
    	System.out.println("usr2_ai3_ce8");
    } 
}
private  void calculateOutputm16(String input) {
    if((cf && (input.equals("usr4_ai2_VoidReply")))) {
    	cf = false;
    	a2100499434 = 8; 
    	System.out.println("usr2_ai3_ce19");
    } 
}
private  void calculateOutputm17(String input) {
    if(((input.equals("usr1_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = (a2100499434 - 2); 
    	System.out.println("usr2_ai2_ce6");
    } 
}
private  void calculateOutputm18(String input) {
    if((cf && (input.equals("usr3_ai2_re2")))) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = a2100499434; 
    	System.out.println("usr1_ai1_ce20");
    } if(((input.equals("usr3_ai2_re1")) && cf)) {
    	cf = false;
    	a2100499434 = 9; 
    	System.out.println("usr4_ai2_ce2");
    } 
}
private  void calculateOutputm19(String input) {
    if(((input.equals("ai1_ce1")) && cf)) {
    	cf = false;
    	a2100499434 = 11; 
    	System.out.println("usr3_ai2_ce8");
    } 
}
private  void calculateOutputm20(String input) {
    if((cf && (input.equals("usr1_ai1_VoidReply")))) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = ((a2100499434 / a2100499434) - -9); 
    	System.out.println("usr1_ai2_ce3");
    } 
}
private  void calculateOutputm21(String input) {
    if((cf && (input.equals("usr2_ai3_VoidReply")))) {
    	cf = false;
    	a744592626 = "i";
    	a2046636204 = ((a2100499434 * a2100499434) + -191); 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm22(String input) {
    if(((input.equals("usr1_ai2_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = (a2046636204 + 3); 
    	System.out.println("usr2_ai2_ce5");
    } 
}
private  void calculateOutputm23(String input) {
    if(((input.equals("usr1_ai1_VoidReply")) && cf)) {
    	cf = false;
    	a2046636204 = 7; 
    	System.out.println("usr1_ai1_ce8");
    } 
}
private  void calculateOutputm24(String input) {
    if(((input.equals("usr1_ai1_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "f";
    	a1143678624 = ((((93 * 33) / 10) - -3092) / 5); 
    	System.out.println("usr1_ai2_ce3");
    } 
}
private  void calculateOutputm25(String input) {
    if(((input.equals("usr2_ai3_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "e";
    	a1614029224 = (a2046636204 - -3); 
    	System.out.println("usr2_ai2_ce14");
    } 
}
private  void calculateOutputm26(String input) {
    if(((input.equals("usr1_ai1_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "f";
    	a1143678624 = ((((36 - 5449) + -6439) - -20391) - 29820); 
    	System.out.println("usr1_ai2_ce10");
    } 
}
private  void calculateOutputm27(String input) {
    if(((input.equals("usr1_ai1_VoidReply")) && cf)) {
    	cf = false;
    	a744592626 = "h";
    	a2100499434 = (a2046636204 - -1); 
    	System.out.println("ai1_re2");
    } 
}



public  void calculateOutput(String input) {
 	cf = true;
    if((cf && (a744592626.equals("e")))) {
    	if((cf && (a1614029224 == 6))) {
    		calculateOutputm1(input);
    	} 
    	if(((a1614029224 == 7) && cf)) {
    		calculateOutputm2(input);
    	} 
    	if(((a1614029224 == 8) && cf)) {
    		calculateOutputm3(input);
    	} 
    	if(((a1614029224 == 9) && cf)) {
    		calculateOutputm4(input);
    	} 
    	if((cf && (a1614029224 == 10))) {
    		calculateOutputm5(input);
    	} 
    	if(((a1614029224 == 11) && cf)) {
    		calculateOutputm6(input);
    	} 
    	if((cf && (a1614029224 == 12))) {
    		calculateOutputm7(input);
    	} 
    } 
    if((cf && (a744592626.equals("f")))) {
    	if((a1143678624 <=  23 && cf)) {
    		calculateOutputm8(input);
    	} 
    	if((cf && ((83 < a1143678624) && (299 >= a1143678624)))) {
    		calculateOutputm9(input);
    	} 
    	if((299 < a1143678624 && cf)) {
    		calculateOutputm10(input);
    	} 
    } 
    if((cf && (a744592626.equals("g")))) {
    	if((cf && a2018512586 <=  -166)) {
    		calculateOutputm11(input);
    	} 
    	if((((-166 < a2018512586) && (36 >= a2018512586)) && cf)) {
    		calculateOutputm12(input);
    	} 
    	if((((36 < a2018512586) && (205 >= a2018512586)) && cf)) {
    		calculateOutputm13(input);
    	} 
    } 
    if(((a744592626.equals("h")) && cf)) {
    	if((cf && (a2100499434 == 7))) {
    		calculateOutputm14(input);
    	} 
    	if((cf && (a2100499434 == 8))) {
    		calculateOutputm15(input);
    	} 
    	if((cf && (a2100499434 == 9))) {
    		calculateOutputm16(input);
    	} 
    	if((cf && (a2100499434 == 10))) {
    		calculateOutputm17(input);
    	} 
    	if((cf && (a2100499434 == 11))) {
    		calculateOutputm18(input);
    	} 
    	if((cf && (a2100499434 == 12))) {
    		calculateOutputm19(input);
    	} 
    	if(((a2100499434 == 13) && cf)) {
    		calculateOutputm20(input);
    	} 
    	if(((a2100499434 == 14) && cf)) {
    		calculateOutputm21(input);
    	} 
    } 
    if((cf && (a744592626.equals("i")))) {
    	if(((a2046636204 == 4) && cf)) {
    		calculateOutputm21(input);
    	}
    	if(((a2046636204 == 5) && cf)) {
    		calculateOutputm23(input);
    	} 
    	if((cf && (a2046636204 == 7))) {
    		calculateOutputm24(input);
    	} 
    	if(((a2046636204 == 9) && cf)) {
    		calculateOutputm25(input);
    	} 
    	if((cf && (a2046636204 == 10))) {
    		calculateOutputm26(input);
    	} 
    	if(((a2046636204 == 11) && cf)) {
    		calculateOutputm27(input);
    	} 
    } 


    if(cf)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main(String[] args) throws Exception {
	// init system and input reader
	m158_LTL eca = new m158_LTL();

	// main i/o-loop
	while(true) {
		//read input
		String input = stdin.readLine();

		 if((input.equals("usr3_ai2_re1")) && (input.equals("usr3_ai2_re2")) && (input.equals("usr2_ai3_re7")) && (input.equals("usr2_ai3_re8")) && (input.equals("usr2_ai3_re9")) && (input.equals("usr4_ai2_VoidReply")) && (input.equals("usr1_ai1_VoidReply")) && (input.equals("usr2_ai3_VoidReply")) && (input.equals("usr1_ai2_VoidReply")) && (input.equals("usr2_ai2_VoidReply")) && (input.equals("usr2_ai3_re12")) && (input.equals("usr2_ai3_re19")) && (input.equals("ai1_ce1")) && (input.equals("usr2_ai3_re13")) && (input.equals("usr2_ai3_re10")) && (input.equals("usr2_ai3_re11")) && (input.equals("usr2_ai3_re14")))
			throw new IllegalArgumentException("Current state has no transition for this input!");
		try {
			//operate eca engine output = 
			eca.calculateOutput(input);
		} catch(IllegalArgumentException e) {
			System.err.println("Invalid input: " + e.getMessage());
		}
	}
}
}